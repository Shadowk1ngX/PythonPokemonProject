import tkinter as tk

TILE_SIZE = 32
MAP_WIDTH = 10
MAP_HEIGHT = 10
player_pos = [5, 5]

root = tk.Tk()
canvas = tk.Canvas(root, width=TILE_SIZE * MAP_WIDTH, height=TILE_SIZE * MAP_HEIGHT)
canvas.pack()

# Load image sprites
grass_img = tk.PhotoImage(file="Assets/Images/Grass.png")     # 32x32 sprite
player_img = tk.PhotoImage(file="Assets/Images/Player.png")   # 32x32 sprite

# Keep a reference so Tkinter doesn't garbage collect them
canvas.grass_img = grass_img
canvas.player_img = player_img

# Example map (just grass)
tile_map = [["G" for _ in range(MAP_WIDTH)] for _ in range(MAP_HEIGHT)]

def draw_map():
    canvas.delete("all")
    for y in range(MAP_HEIGHT):
        for x in range(MAP_WIDTH):
            canvas.create_image(x * TILE_SIZE, y * TILE_SIZE, image=grass_img, anchor="nw")
    # Draw player
    canvas.create_image(player_pos[0] * TILE_SIZE, player_pos[1] * TILE_SIZE, image=player_img, anchor="nw")

def move(event):
    if event.keysym == "Up" and player_pos[1] > 0:
        player_pos[1] -= 1
    elif event.keysym == "Down" and player_pos[1] < MAP_HEIGHT - 1:
        player_pos[1] += 1
    elif event.keysym == "Left" and player_pos[0] > 0:
        player_pos[0] -= 1
    elif event.keysym == "Right" and player_pos[0] < MAP_WIDTH - 1:
        player_pos[0] += 1
    draw_map()

root.bind("<KeyPress>", move)
draw_map()
root.mainloop()
